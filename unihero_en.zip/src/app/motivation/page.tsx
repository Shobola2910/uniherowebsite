import SectionHeader from "@/components/SectionHeader";

const QUOTES = [
  "The future belongs to those who prepare today.",
  "Study for growth, not just grades.",
  "One page a day keeps regret away."
];

export default function MotivationPage() {
  return (
    <section>
      <SectionHeader title="Motivation 🌅" subtitle="Daily inspiration for students" />
      <div className="rounded-2xl bg-white/5 p-8 text-center">
        <p className="text-xl">{QUOTES[0]}</p>
        <p className="mt-2 text-white/70 text-sm">Rotating quotes can be added via a small client component.</p>
      </div>
      <div className="mt-6">
        <a href="https://t.me/UniHero_news" className="inline-flex items-center gap-2 rounded-2xl border border-white/20 px-4 py-2 hover:bg-white/10 transition">
          💬 Get Daily Motivation → @UniHero_news
        </a>
      </div>
    </section>
  );
}
