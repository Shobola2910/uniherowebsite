import SectionHeader from "@/components/SectionHeader";
import Card from "@/components/Card";
import { RESOURCES } from "@/lib/data";

export default function ResourcesPage() {
  return (
    <section>
      <SectionHeader title="Explore Our Resources 📘" subtitle="Everything you need to study smarter" />
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {RESOURCES.map((r) => (
          <Card key={r.title} title={r.title} desc={r.desc_en} icon={<span>{r.icon}</span>} />
        ))}
      </div>
      <p className="mt-6 text-white/80 text-sm">
        Need custom help? Chat our bot 👉 <a className="underline" href="https://t.me/UniHero_BOT">@UniHero_BOT</a>
      </p>
    </section>
  );
}
