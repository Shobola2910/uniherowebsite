import "./globals.css";
import type { Metadata } from "next";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: "UniHero — For Students, By Students",
  description: "UniHero helps university students with resources, exam prep, and motivation.",
  openGraph: {
    title: "UniHero — For Students, By Students",
    description: "Community, resources, exam prep, and daily motivation for students.",
    images: ["/og-image.png"]
  },
  icons: { icon: "/icon.png" }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-dvh antialiased selection:bg-unihero-accent/30">
        <Navbar />
        <main className="mx-auto max-w-6xl px-4 pt-28 pb-24">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
