export const RESOURCES = [
  { icon: "📄", title: "Assignments", desc_en: "Guides and templates for every subject." },
  { icon: "🧮", title: "Exam Prep", desc_en: "Summaries, formula sheets, and past papers." },
  { icon: "🕒", title: "Time Management", desc_en: "Planners, checklists, and focus methods." },
  { icon: "💭", title: "Motivation", desc_en: "Daily quotes and student success stories." }
];

export const TESTIMONIALS = [
  { text_en: "UniHero helped me prepare for my FINC exam with confidence!", author: "Kamilla, MDIST" },
  { text_en: "Resources are practical and the community replies fast.", author: "Nodir" }
];
