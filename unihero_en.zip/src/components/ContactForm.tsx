"use client";
import { useState } from "react";

export default function ContactForm() {
  const [sent, setSent] = useState(false);
  return (
    <form
      className="space-y-3"
      onSubmit={(e) => {
        e.preventDefault();
        setSent(true);
      }}
    >
      <input className="w-full rounded-2xl bg-white/5 px-4 py-3 outline-none focus:ring-2 focus:ring-white/30" placeholder="Name" required/>
      <input className="w-full rounded-2xl bg-white/5 px-4 py-3 outline-none focus:ring-2 focus:ring-white/30" placeholder="Email" type="email" required/>
      <textarea className="w-full rounded-2xl bg-white/5 px-4 py-3 outline-none focus:ring-2 focus:ring-white/30" rows={4} placeholder="Message" required/>
      <button className="rounded-2xl bg-unihero-accent px-5 py-2.5 font-medium shadow hover:scale-[1.02] transition">
        {sent ? "✅ Sent!" : "Send Message"}
      </button>
    </form>
  );
}
