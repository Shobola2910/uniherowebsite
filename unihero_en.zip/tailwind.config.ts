import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/app/**/*.{ts,tsx}",
    "./src/components/**/*.{ts,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        unihero: {
          navy: "#0A1F44",
          accent: "#007BFF",
          surface: "#EAF2FD",
          textdark: "#1F1F1F"
        }
      },
      borderRadius: {
        "2xl": "16px"
      },
      boxShadow: {
        soft: "0 10px 30px rgba(10,31,68,.12)"
      },
      keyframes: {
        floatY: { "0%,100%": { transform: "translateY(0)" }, "50%": { transform: "translateY(-6px)" } },
        shimmer: { "0%": { backgroundPosition: "-200% 0" }, "100%": { backgroundPosition: "200% 0" } }
      },
      animation: {
        floatY: "floatY 10s ease-in-out infinite",
        shimmer: "shimmer 1.2s linear infinite"
      }
    }
  },
  plugins: []
};
export default config;
