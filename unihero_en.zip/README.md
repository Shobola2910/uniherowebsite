# UniHero — For Students, By Students 🎓

English-only, mobile-ready website using **Next.js 14 (App Router) + Tailwind CSS + Framer Motion**.

- Custom favicon & navbar logo (your provided image)
- Hamburger menu on mobile
- Clean sections: Home, About, Resources, Community, Events, Contact, Motivation

## Quick Start
```bash
npm install
npm run dev
# http://localhost:3000
```
